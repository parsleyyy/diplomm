﻿using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Word = Microsoft.Office.Interop.Word;
using Интернет_Провайдер.DataFiles;

namespace Интернет_Провайдер.fZakazchick
{
    /// <summary>
    /// Логика взаимодействия для PageViewZayavka.xaml
    /// </summary>
    public partial class PageViewZayavka : Page
    {
        string TemplateFileName = Directory.GetCurrentDirectory() + @"\Макет_договора.docx";
        int zakazID = PageLogin.EmpID;
        private static Заказчик zak;
        public PageViewZayavka(Заказчик Zak)
        {
            InitializeComponent();
            zak = Zak;
            GridList.ItemsSource = ConnectHelper.entObj.Заказ.Where(z => z.Код_Исполнителя == zakazID).ToList();
        }

        private void btnOtch_Click(object sender, RoutedEventArgs e)
        {
            var wordApp = new Word.Application();
            wordApp.Visible = false;

            var zakaz = ConnectHelper.entObj.Заказ.FirstOrDefault(x => x.Код_Зазчика == zakazID);
            var zakazchick = ConnectHelper.entObj.Заказчик.FirstOrDefault(x => x.Код_Заказчика == zakaz.Код_Зазчика);
            var Ispol = ConnectHelper.entObj.Исполнитель.FirstOrDefault(x => x.Код_Исполнителя == zakaz.Код_Исполнителя);
            var city = ConnectHelper.entObj.Город.FirstOrDefault(x => x.Код_Города == zakazchick.Код_Города);
            var yslyga = ConnectHelper.entObj.Услуги.FirstOrDefault(x => x.Код_Услуг == zakaz.Код_Услуги);



            try
            {
                var wordDocument = wordApp.Documents.Open(TemplateFileName);
                ReplaceWordStud("{Nomer}", zakaz.Код_Заказа.ToString(), wordDocument);

                ReplaceWordStud("{FIO zak}", zakazchick.ФИО.ToString(), wordDocument);

                ReplaceWordStud("{FIO Islp}", Ispol.ФИО.ToString(), wordDocument);

                ReplaceWordStud("{City}", city.Название.ToString(), wordDocument);

                ReplaceWordStud("{Street}", zakazchick.Улица_Дом.ToString(), wordDocument);

                ReplaceWordStud("{OpisanZayavka}", zakaz.Доп_Инфа.ToString(), wordDocument);

                ReplaceWordStud("{NameYslyga}", yslyga.Название.ToString(), wordDocument);

                ReplaceWordStud("{Date}", zakaz.Дата.ToString(), wordDocument);

                ReplaceWordStud("{Sum}", zakaz.Стоимость.ToString(), wordDocument);



                wordDocument.SaveAs2(Directory.GetCurrentDirectory() + @"\Договор.docx");
                wordApp.Visible = true;
            }
            catch
            {
                MessageBox.Show("Произошла ошибка при добавлении!");
            }
        }
        private void ReplaceWordStud(string studToReplace, string text, Word.Document wordDocument)
        {
            var range = wordDocument.Content;
            range.Find.ClearFormatting();
            range.Find.Execute(FindText: studToReplace, ReplaceWith: text);
        }
        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }
    }
}
