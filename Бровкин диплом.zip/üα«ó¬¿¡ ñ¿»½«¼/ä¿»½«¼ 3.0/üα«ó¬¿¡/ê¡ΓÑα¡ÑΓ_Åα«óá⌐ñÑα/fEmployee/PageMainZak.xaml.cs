﻿using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Интернет_Провайдер.DataFiles;

namespace Интернет_Провайдер.fZakazchick
{
    /// <summary>
    /// Логика взаимодействия для PageMainZak.xaml
    /// </summary>
    public partial class PageMainZak : Page
    {
        int empID = PageLogin.EmpID;
        public PageMainZak()
        {
            InitializeComponent();
            var employee = ConnectHelper.entObj.Исполнитель.FirstOrDefault(x => x.Код_Исполнителя == empID);
            var gorod = ConnectHelper.entObj.Город.FirstOrDefault(x => x.Код_Города == employee.Код_Города);

            lFio.Content = employee.ФИО;
            lCity.Content = gorod.Название + ", " + employee.Улица_Дом;
            lPhone.Content = employee.Телефон;
            lVK.Content = employee.ВКонтакте;
        }

        private void btn_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageAddZayavka());
        }

        private void btn1_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageViewZayavka((sender as Button).DataContext as Заказчик));
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }
    }
}
