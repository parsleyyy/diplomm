﻿using System.Windows;
using Интернет_Провайдер.DataFiles;

namespace Интернет_Провайдер
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            FrameApp.frmObj = FrmMain;
            ConnectHelper.entObj = new Заявки_ИнтернетEntities();

            FrmMain.Navigate(new PageLogin());
        }
    }
}
