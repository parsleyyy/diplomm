﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Интернет_Провайдер.DataFiles;

namespace Интернет_Провайдер.fAdmin.fAdd
{
    /// <summary>
    /// Логика взаимодействия для PageAddZakaz.xaml
    /// </summary>
    public partial class PageAddZakaz : Page
    {
        public PageAddZakaz()
        {
            InitializeComponent();
            cmbYslyg.SelectedValuePath = "Код_Услуг";
            cmbYslyg.DisplayMemberPath = "Название";
            cmbYslyg.ItemsSource = ConnectHelper.entObj.Услуги.ToList();

            cmbIspl.SelectedValuePath = "Код_Исполнителя";
            cmbIspl.DisplayMemberPath = "ФИО";
            cmbIspl.ItemsSource = ConnectHelper.entObj.Исполнитель.ToList();

            cmbZak.SelectedValuePath = "Код_Заказчика";
            cmbZak.DisplayMemberPath = "ФИО";
            cmbZak.ItemsSource = ConnectHelper.entObj.Заказчик.ToList();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }

        private void btnAddZakaz_Click(object sender, RoutedEventArgs e)
        {
            if (cmbIspl.SelectedValue == null && cmbYslyg.SelectedValue == null && cmbZak.SelectedValue == null && dpDate.SelectedDate == null && tbCount.Text.Length < 1)
                MessageBox.Show("Поля не могут быть пустыми", "Ошибка добавления", MessageBoxButton.OK, MessageBoxImage.Warning);
            else if (cmbIspl.SelectedValue == null)
                MessageBox.Show("Выберите Исполнителя", "Ошибка добавления", MessageBoxButton.OK, MessageBoxImage.Warning);
            else if (tbCount.Text.Length < 1)
                MessageBox.Show("Заполните КолВО", "Ошибка добавления", MessageBoxButton.OK, MessageBoxImage.Warning);
            else if (cmbYslyg.SelectedValue == null)
                MessageBox.Show("Выберите Услугу", "Ошибка добавления", MessageBoxButton.OK, MessageBoxImage.Warning);
            else if (cmbZak.SelectedValue == null)
                MessageBox.Show("Выберите Заказчика", "Ошибка добавления", MessageBoxButton.OK, MessageBoxImage.Warning);
            else if (dpDate.SelectedDate == null)
                MessageBox.Show("Выберите Дату", "Ошибка добавления", MessageBoxButton.OK, MessageBoxImage.Warning);
            else if (ConnectHelper.entObj.Заказ.Where(x => x.Код_Услуги == (int)cmbYslyg.SelectedValue && x.Код_Исполнителя == (int)cmbIspl.SelectedValue && x.КолВо.ToString() == tbCount.Text &&
             x.Стоимость.ToString() == tbItog.Text && x.Дата == dpDate.SelectedDate && x.КолВо.ToString() == tbCount.Text).Count() > 0)
                MessageBox.Show("Такой заказ уже есть!", "Ошибка добавления", MessageBoxButton.OK, MessageBoxImage.Warning);
            else
            {
                try
                {
                    Заказ заказ = new Заказ()
                    {
                        Код_Зазчика = (int)cmbZak.SelectedValue,
                        Код_Исполнителя = (int)cmbIspl.SelectedValue,
                        Код_Услуги = (int)cmbYslyg.SelectedValue,
                        КолВо = Convert.ToInt32(tbCount.Text),
                        Доп_Инфа = tbOpis.Text,
                        Стоимость = int.Parse(tbItog.Text),
                        Дата = (DateTime)dpDate.SelectedDate,
                        Код_Статуса = 1
                    };
                    ConnectHelper.entObj.Заказ.Add(заказ);
                    ConnectHelper.entObj.SaveChanges();
                    MessageBox.Show("Заказ успешно добавлен", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex)
                { MessageBox.Show(ex.Message, "Критическая ошибка!", MessageBoxButton.OK, MessageBoxImage.Error); }
            }
        }

        private void tbCount_TextChanged(object sender, TextChangedEventArgs e)
        {
            if(tbCount.Text.Length > 0 && cmbYslyg.SelectedValue != null)
            {
                var yslyga = ConnectHelper.entObj.Услуги.SingleOrDefault(x => x.Код_Услуг == (int)cmbYslyg.SelectedValue);
                tbItog.Text = (yslyga.Цена * Decimal.Parse(tbCount.Text)).ToString();
            }
        }
    }
}
