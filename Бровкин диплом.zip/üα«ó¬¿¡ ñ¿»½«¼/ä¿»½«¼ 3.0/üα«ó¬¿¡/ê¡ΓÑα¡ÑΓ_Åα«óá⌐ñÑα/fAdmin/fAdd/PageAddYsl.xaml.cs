﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Интернет_Провайдер.DataFiles;

namespace Интернет_Провайдер.fAdmin.fAdd
{
    /// <summary>
    /// Логика взаимодействия для PageAddYsl.xaml
    /// </summary>
    public partial class PageAddYsl : Page
    {
        public PageAddYsl()
        {
            InitializeComponent();
            tbName.Text = "";
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }

        private void btnAddDolzh_Click(object sender, RoutedEventArgs e)
        {
            if (tbName.Text.Length <1 && tbPrice.Text.Length < 1)
                MessageBox.Show("Поля не могут быть пустыми", "Ошибка добавления", MessageBoxButton.OK, MessageBoxImage.Warning);
            else if (tbName.Text.Length < 1)
                MessageBox.Show("Заполните Название", "Ошибка добавления", MessageBoxButton.OK, MessageBoxImage.Warning);
            else if (tbPrice.Text.Length < 1)
                MessageBox.Show("Заполните цену!", "Ошибка добавления", MessageBoxButton.OK, MessageBoxImage.Warning);
            else
            {
                try
                {
                    Услуги stdObj = new Услуги()
                    {
                        Название = tbName.Text,
                        Цена = int.Parse(tbPrice.Text)
                    };

                    ConnectHelper.entObj.Услуги.Add(stdObj);
                    ConnectHelper.entObj.SaveChanges();

                    MessageBox.Show("Услуга добавлена!",
                                    "Уведомление",
                                    MessageBoxButton.OK,
                                    MessageBoxImage.Information
                                    );

                }
                catch (Exception ex)
                {
                    MessageBox.Show(
                        "Критическая работа с приложением: " + ex.Message.ToString(),
                        "Уведомление",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning
                        );
                }
            }
        }
    }
}
