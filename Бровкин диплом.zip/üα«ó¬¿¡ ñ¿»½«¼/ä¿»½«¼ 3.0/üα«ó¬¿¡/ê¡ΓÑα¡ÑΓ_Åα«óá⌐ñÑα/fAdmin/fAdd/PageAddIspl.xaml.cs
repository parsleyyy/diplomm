﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Интернет_Провайдер.DataFiles;

namespace Интернет_Провайдер.fAdmin.fAdd
{
    /// <summary>
    /// Логика взаимодействия для PageAddIspl.xaml
    /// </summary>
    public partial class PageAddIspl : Page
    {
        public PageAddIspl()
        {
            InitializeComponent();
            tbFio.Text = "";
            tbPhone.Text = "";
            tbStreet.Text = "";
            tbVK.Text = "";
            cmbCity.Text = "";

            cmbCity.SelectedValuePath = "Код_Города";
            cmbCity.DisplayMemberPath = "Название";
            cmbCity.ItemsSource = ConnectHelper.entObj.Город.ToList();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }

        private void btnAddDolzh_Click(object sender, RoutedEventArgs e)
        {
            if (tbFio.Text == "" && tbPhone.Text == "" && tbStreet.Text == "" && cmbCity.Text == "" && tbVK.Text == "")
            {
                MessageBox.Show("Поля нельзя оставлять пустыми!");
            }
            else
            {
                try
                {
                    Исполнитель stdObj = new Исполнитель()
                    {
                        ФИО = tbFio.Text,
                        Телефон = tbPhone.Text,
                        Улица_Дом = tbStreet.Text,
                        Город = cmbCity.SelectedItem as Город,
                        ВКонтакте = tbVK.Text,
                    };

                    ConnectHelper.entObj.Исполнитель.Add(stdObj);
                    ConnectHelper.entObj.SaveChanges();

                    MessageBox.Show("Исполнитель добавлен!",
                                   "Уведомление",
                                   MessageBoxButton.OK,
                                   MessageBoxImage.Information);

                    Пользователь polz = new Пользователь()
                    {
                        Логин = tbLog.Text,
                        Пароль = tbPas.Text,
                        Код_Роли = 2,
                        Код_Исполнителя = stdObj.Код_Исполнителя,
                    };

                    ConnectHelper.entObj.Пользователь.Add(polz);
                    ConnectHelper.entObj.SaveChanges();

                    MessageBox.Show("Пользователь добавлен!",
                                    "Уведомление",
                                    MessageBoxButton.OK,
                                    MessageBoxImage.Information);

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Критическая работа с приложением: " + ex.Message.ToString(),
                        "Уведомление",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning);
                }
            }
        }
    }
}