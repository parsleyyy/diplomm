﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Интернет_Провайдер.DataFiles;

namespace Интернет_Провайдер.fAdmin.fAdd
{
    /// <summary>
    /// Логика взаимодействия для PageAddZakazchik.xaml
    /// </summary>
    public partial class PageAddZakazchik : Page
    {
        public PageAddZakazchik()
        {
            InitializeComponent();

            cmbCity.SelectedValuePath = "Код_Города";
            cmbCity.DisplayMemberPath = "Название";
            cmbCity.ItemsSource = ConnectHelper.entObj.Город.ToList();
        }

        private void BtnReg_Click(object sender, RoutedEventArgs e)
        {
            if (tbFio.Text.Length < 1 && tbPhone.Text.Length < 1 && tbStreet.Text.Length < 1 && tbVK.Text.Length < 1 && cmbCity.SelectedValue == null)
                MessageBox.Show("Поля не могут быть пустыми", "Ошибка добавления", MessageBoxButton.OK, MessageBoxImage.Warning);
            else if (tbFio.Text.Length < 1)
                MessageBox.Show("Заполните поле Ф.И.О","Ошибка добавления",MessageBoxButton.OK,MessageBoxImage.Warning);
            else if (tbPhone.Text.Length < 1)
                MessageBox.Show("Заполните поле Номер телефона", "Ошибка добавления", MessageBoxButton.OK, MessageBoxImage.Warning);
            else if (tbStreet.Text.Length < 1)
                MessageBox.Show("Заполните поле Улица", "Ошибка добавления", MessageBoxButton.OK, MessageBoxImage.Warning);
            else if (cmbCity.SelectedValue == null)
                MessageBox.Show("Выберите Город", "Ошибка добавления", MessageBoxButton.OK, MessageBoxImage.Warning);
            else if(ConnectHelper.entObj.Заказчик.Where(x => x.ФИО == tbFio.Text && x.Телефон == tbPhone.Text && x.Улица_Дом == tbStreet.Text && x.Код_Города == (int)cmbCity.SelectedValue).Count() > 0)
                MessageBox.Show("Такой заказчик уже есть!", "Ошибка добавления", MessageBoxButton.OK, MessageBoxImage.Warning);
            else
            {
                try
                {
                    if(tbVK.Text.Length < 1)
                    {
                        Заказчик заказчик = new Заказчик()
                        {
                            ФИО = tbFio.Text,
                            Телефон = tbPhone.Text,
                            Улица_Дом = tbStreet.Text,
                            Код_Города = (int)cmbCity.SelectedValue,
                            ВКонтакте = null
                        };
                        ConnectHelper.entObj.Заказчик.Add(заказчик);
                        ConnectHelper.entObj.SaveChanges();
                        MessageBox.Show("Новый заказчик успешно добавлен!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    else
                    {
                        Заказчик заказчик = new Заказчик()
                        {
                            ФИО = tbFio.Text,
                            Телефон = tbPhone.Text,
                            Улица_Дом = tbStreet.Text,
                            Код_Города = (int)cmbCity.SelectedValue,
                            ВКонтакте = tbVK.Text
                        };
                        ConnectHelper.entObj.Заказчик.Add(заказчик);
                        ConnectHelper.entObj.SaveChanges();
                        MessageBox.Show("Новый заказчик успешно добавлен!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                    }

                }
                catch (Exception ex)
                { MessageBox.Show(ex.Message, "Критическая ошибка!", MessageBoxButton.OK, MessageBoxImage.Error); }

            }
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }
    }
}
