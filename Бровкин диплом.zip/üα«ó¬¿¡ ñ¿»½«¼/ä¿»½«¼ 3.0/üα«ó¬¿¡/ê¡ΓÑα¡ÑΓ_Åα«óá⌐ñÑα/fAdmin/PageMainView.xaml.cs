﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Интернет_Провайдер.DataFiles;
using Интернет_Провайдер.fAdmin.fView;

namespace Интернет_Провайдер.fAdmin
{
    /// <summary>
    /// Логика взаимодействия для PageMainView.xaml
    /// </summary>
    public partial class PageMainView : Page
    {
        public PageMainView()
        {
            InitializeComponent();
        }

        private void btnViewYsl_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageViewYsl());
        }

        private void btnViewZak_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageViewZak());
        }

        private void btnViewIpl_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageViewIspl());
        }

        private void btnViewCity_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageViewCity());
        }

        private void btnViewZakaz_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageViewZakaz());
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }
    }
}
