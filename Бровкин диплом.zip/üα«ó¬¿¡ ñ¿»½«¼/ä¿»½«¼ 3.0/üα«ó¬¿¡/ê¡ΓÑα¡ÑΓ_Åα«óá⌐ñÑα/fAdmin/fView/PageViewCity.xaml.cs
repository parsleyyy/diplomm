﻿using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Интернет_Провайдер.DataFiles;
using Интернет_Провайдер.fAdmin.fAdd;

namespace Интернет_Провайдер.fAdmin.fView
{
    /// <summary>
    /// Логика взаимодействия для PageViewCity.xaml
    /// </summary>
    public partial class PageViewCity : Page
    {
        public PageViewCity()
        {
            InitializeComponent();
            GridList.ItemsSource = ConnectHelper.entObj.Город.ToList();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }

        private void btnAddCity_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageAddCity());
        }

        private void btnRemCity_Click(object sender, RoutedEventArgs e)
        {
            Город City = GridList.SelectedItem as Город;
            if (City == null)
            {
                MessageBox.Show("Не выбранно поле для удаления", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            else
            {
                if (MessageBox.Show("Удалить эту запись: " + $" {City.Название}?", "Удаление", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    try
                    {
                        ConnectHelper.entObj.Город.Remove(City);
                        ConnectHelper.entObj.SaveChanges();
                        MessageBox.Show("Запись удалена", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);

                        GridList.ItemsSource = ConnectHelper.entObj.Город.ToList();
                    }
                    catch
                    {
                        MessageBox.Show("Данная запись используется в другом месте. Прежде чем ее удалить удостоверьтесь что она нигде не используется!",
                            "Уведомление", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                }
            }
        }
    }
}