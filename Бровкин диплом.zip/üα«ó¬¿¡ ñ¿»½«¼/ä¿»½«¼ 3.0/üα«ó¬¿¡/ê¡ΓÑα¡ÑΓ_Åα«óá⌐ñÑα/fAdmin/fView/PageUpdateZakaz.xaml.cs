﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Интернет_Провайдер.DataFiles;

namespace Интернет_Провайдер.fAdmin.fView
{
    /// <summary>
    /// Логика взаимодействия для PageUpdateZakaz.xaml
    /// </summary>
    public partial class PageUpdateZakaz : Page
    {
        private static Заказ zak;
        public PageUpdateZakaz(Заказ Zak)
        {
            InitializeComponent();
            zak = Zak;
            var Zakaz = ConnectHelper.entObj.Заказ.FirstOrDefault(z => z.Код_Заказа == Zak.Код_Заказа);
            var zakazchick = ConnectHelper.entObj.Заказчик.FirstOrDefault(z => z.Код_Заказчика == Zakaz.Код_Зазчика);

            var ispol = ConnectHelper.entObj.Исполнитель.FirstOrDefault(z => z.Код_Исполнителя == Zakaz.Код_Исполнителя);
            var stat = ConnectHelper.entObj.Статус.FirstOrDefault(z => z.Код_Статуса == Zakaz.Код_Статуса);
            var ysl = ConnectHelper.entObj.Услуги.FirstOrDefault(z => z.Код_Услуг == Zakaz.Код_Услуги);

            cmbYslyg.SelectedValuePath = "Код_Услуги";
            cmbYslyg.DisplayMemberPath = "Название";
            cmbYslyg.ItemsSource = ConnectHelper.entObj.Услуги.ToList();

            cmbStat.SelectedValuePath = "Код_Статуса";
            cmbStat.DisplayMemberPath = "Название";
            cmbStat.ItemsSource = ConnectHelper.entObj.Статус.ToList();

            cmbIsp.SelectedValuePath = "Код_Исполнителя";
            cmbIsp.DisplayMemberPath = "ФИО";
            cmbIsp.ItemsSource = ConnectHelper.entObj.Исполнитель.ToList();

            cmbYslyg.Text = ysl.Название;
            cmbStat.Text = stat.Название;
            cmbIsp.Text = ispol.ФИО;

            tbOpis.Text = Zakaz.Доп_Инфа;
            tbSum.Text = Convert.ToString(Zakaz.Стоимость);
            tbZak.Text = zakazchick.ФИО;
            dpDate.SelectedDate = Zakaz.Дата;
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }

        private void btnAddDolzh_Click(object sender, RoutedEventArgs e)
        {
            ConnectHelper.entObj.SaveChanges();
            var Zakaz = ConnectHelper.entObj.Заказ.FirstOrDefault(z => z.Код_Заказа == zak.Код_Заказа);
            var zakazchick = ConnectHelper.entObj.Заказчик.FirstOrDefault(z => z.Код_Заказчика == Zakaz.Код_Зазчика);

            var ispol = ConnectHelper.entObj.Исполнитель.FirstOrDefault(z => z.Код_Исполнителя == Zakaz.Код_Исполнителя);
            var stat = ConnectHelper.entObj.Статус.FirstOrDefault(z => z.Код_Статуса == Zakaz.Код_Статуса);
            var ysl = ConnectHelper.entObj.Услуги.FirstOrDefault(z => z.Код_Услуг == Zakaz.Код_Услуги);

            cmbYslyg.Text = ysl.Название;
            cmbStat.Text = stat.Название;
            cmbIsp.Text = ispol.ФИО;

            tbOpis.Text = Zakaz.Доп_Инфа;
            tbSum.Text = Convert.ToString(Zakaz.Стоимость);
            tbZak.Text = zakazchick.ФИО;
            dpDate.SelectedDate = Zakaz.Дата;
            try
            {
                Заказ stdObj = new Заказ()
                {
                    Услуги = cmbYslyg.SelectedItem as Услуги,
                    Статус = cmbStat.SelectedItem as Статус,
                    Исполнитель = cmbIsp.SelectedItem as Исполнитель,

                    Доп_Инфа = tbOpis.Text,
                    Стоимость = int.Parse(tbSum.Text)
                };

                ConnectHelper.entObj.Заказ.Attach(stdObj);
                ConnectHelper.entObj.SaveChanges();

                MessageBox.Show("Заказ добавлен!",
                                "Уведомление",
                                MessageBoxButton.OK,
                                MessageBoxImage.Information);
                MessageBox.Show("Изменения сохранены!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Критическая работа с приложением: " + ex.Message.ToString(),
                    "Уведомление",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
            }
        }
    }
}