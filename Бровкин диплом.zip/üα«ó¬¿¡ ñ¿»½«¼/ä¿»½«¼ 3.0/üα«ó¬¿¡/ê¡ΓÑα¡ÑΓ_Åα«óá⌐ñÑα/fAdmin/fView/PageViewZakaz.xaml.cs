﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Excel = Microsoft.Office.Interop.Excel;
using Интернет_Провайдер.DataFiles;
using Интернет_Провайдер.fAdmin.fAdd;

namespace Интернет_Провайдер.fAdmin.fView
{
    /// <summary>
    /// Логика взаимодействия для PageViewZakaz.xaml
    /// </summary>
    public partial class PageViewZakaz : Page
    {
        public PageViewZakaz()
        {
            InitializeComponent();

            cmbIsp.ItemsSource = ConnectHelper.entObj.Исполнитель.ToList();
            cmbIsp.SelectedValuePath = "Код_Исполнителя";
            cmbIsp.DisplayMemberPath = "ФИО";

            cmbZak.ItemsSource = ConnectHelper.entObj.Заказчик.ToList();
            cmbZak.SelectedValuePath = "Код_Заказчика";
            cmbZak.DisplayMemberPath = "ФИО";


            Update();
        }

        void Update()
        {
            GridList.ItemsSource = ConnectHelper.entObj.Заказ.ToList();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            Update();
        }
        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }
        private void btnUpdate_click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageUpdateZakaz((sender as Button).DataContext as Заказ));
        }
       
        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            Заказ зак = GridList.SelectedItem as Заказ;
            if (зак == null)
                MessageBox.Show("Запись для сохранения не выбрана", "Ошибка сохранения", MessageBoxButton.OK, MessageBoxImage.Warning);
            else
            {
                var zakaz = ConnectHelper.entObj.Заказ.Where(x => x.Код_Заказа == зак.Код_Заказа);

                var application = new Excel.Application();
                application.SheetsInNewWorkbook = 1;

                Excel.Workbook workbook = application.Workbooks.Add(Type.Missing);
                Excel.Worksheet worksheet = application.Worksheets[1];
                try
                {
                    worksheet.Name = "Заказ";
                    Excel.Range shapka = worksheet.Range[worksheet.Cells[2][1], worksheet.Cells[10][1]];
                    shapka.Value = "ООО 'Орехово - Зуевский техноторговый центр 'Гарант'' офиц.сайт 'ТТЦ ГАРАНТ.РУ'";
                    shapka.Merge();
                    shapka.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;


                    worksheet.Cells[2][2] = "Наряд - Заказ №: " + зак.Код_Заказа;
                    worksheet.Cells[2][3] = "Заказчик: " + зак.Заказчик.ФИО;
                    worksheet.Cells[2][4] = "Адрес: " + зак.Заказчик.Город.Название + " " + зак.Заказчик.Улица_Дом;
                    worksheet.Cells[2][5] = "Телефон: " + зак.Заказчик.Телефон;
                    worksheet.Cells[2][6] = "Описание: " + зак.Доп_Инфа;

                    worksheet.Cells[5][4] = "Дата выполнения: " + зак.Дата;
                    worksheet.Cells[5][5] = "Исполнитель: " + зак.Исполнитель.ФИО;

                    worksheet.Cells[2][7] = "С условиями услуг прайс-листа согласен. Оплату обязуюсь произвести полностью ________________/Заказчик/";



                    Excel.Range table = worksheet.Range[worksheet.Cells[3][8], worksheet.Cells[5][8 + 2]];
                    table.Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle =
                    table.Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle =
                    table.Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle =
                    table.Borders[Excel.XlBordersIndex.xlEdgeTop].LineStyle =
                    table.Borders[Excel.XlBordersIndex.xlInsideHorizontal].LineStyle =
                    table.Borders[Excel.XlBordersIndex.xlInsideVertical].LineStyle = Excel.XlLineStyle.xlContinuous;

                    table.Cells[1][1] = "Услуга";
                    table.Cells[2][1] = "Цена ₽";
                    table.Cells[3][1] = "КолВО";

                    int i = 2;
                    foreach (var заказ in ConnectHelper.entObj.Заказ.Where(x => x.Код_Заказа == зак.Код_Заказа))
                    {
                        table.Cells[1][i] = заказ.Услуги.Название;
                        table.Cells[2][i] = заказ.Услуги.Цена;
                        table.Cells[3][i] = заказ.КолВо;
                        i++;
                    }
                    worksheet.Cells[4][10] = "Стоимость работ: " + зак.Стоимость;

                    worksheet.Cells[2][12] = "Работу выполнил <____> __________ 20__г";
                    worksheet.Cells[5][12] = "Срок гарантии ______________";
                    worksheet.Cells[2][13] = "Претензий не имею. <____> ______________ 20__г. ____________/Заказчик/";

                    table.Columns.AutoFit();
                    application.Visible = true;
                }
                catch (Exception ex)
                {
                    workbook.Close();
                    MessageBox.Show(ex.Message, "Критическая ошибка!", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageAddZakaz());
        }

        private void btnDel_Click(object sender, RoutedEventArgs e)
        {
            Заказ зак = GridList.SelectedItem as Заказ;
            if (зак == null)
                MessageBox.Show("Запись для удаления не выбрана", "Ошибка удаления", MessageBoxButton.OK, MessageBoxImage.Warning);
            else
            {
                try
                {
                    ConnectHelper.entObj.Заказ.Remove(зак);
                    ConnectHelper.entObj.SaveChanges();
                    GridList.ItemsSource = ConnectHelper.entObj.Заказ.ToList();
                }
                catch (Exception ex)
                { MessageBox.Show(ex.Message, "Критическая ошибка!", MessageBoxButton.OK, MessageBoxImage.Error); }

            }
        }

        private void cmbIsp_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            GridList.ItemsSource = ConnectHelper.entObj.Заказ.Where(x => x.Исполнитель.Код_Исполнителя == (int)cmbIsp.SelectedValue).ToList();
        }

        private void cmbZak_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            GridList.ItemsSource = ConnectHelper.entObj.Заказ.Where(x => x.Заказчик.Код_Заказчика == (int)cmbZak.SelectedValue).ToList();
        }

        
    }
}
