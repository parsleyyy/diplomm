﻿using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Интернет_Провайдер.DataFiles;
using Интернет_Провайдер.fAdmin.fAdd;

namespace Интернет_Провайдер.fAdmin.fView
{
    /// <summary>
    /// Логика взаимодействия для PageViewYsl.xaml
    /// </summary>
    public partial class PageViewYsl : Page
    {
        public PageViewYsl()
        {
            InitializeComponent();
            GridList.ItemsSource = ConnectHelper.entObj.Услуги.ToList();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageAddYsl());
        }

        private void btnRem_Click(object sender, RoutedEventArgs e)
        {
            Услуги Ysl = GridList.SelectedItem as Услуги;
            if (Ysl == null)
            {
                MessageBox.Show("Не выбранно поле для удаления", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            else
            {
                if (MessageBox.Show("Удалить эту запись: " + $" {Ysl.Название}?", "Удаление", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    try
                    {
                        ConnectHelper.entObj.Услуги.Remove(Ysl);
                        ConnectHelper.entObj.SaveChanges();
                        MessageBox.Show("Запись удалена", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);

                        GridList.ItemsSource = ConnectHelper.entObj.Услуги.ToList();
                    }
                    catch
                    {
                        MessageBox.Show("Данная запись используется в другом месте. Прежде чем ее удалить удостоверьтесь что она нигде не используется!",
                            "Уведомление", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                }
            }
        }
    }
}