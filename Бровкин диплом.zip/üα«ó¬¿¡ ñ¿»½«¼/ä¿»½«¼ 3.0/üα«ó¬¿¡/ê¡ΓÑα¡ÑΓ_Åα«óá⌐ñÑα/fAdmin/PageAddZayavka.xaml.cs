﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Интернет_Провайдер.DataFiles;

namespace Интернет_Провайдер.fZakazchick
{
    /// <summary>
    /// Логика взаимодействия для PageAddZayavka.xaml
    /// </summary>
    public partial class PageAddZayavka : Page
    {
        int zakazID = PageLogin.EmpID;
        public PageAddZayavka()
        {
            InitializeComponent();
            cmbYslyg.Text = "";
            tbOpis.Text = "";
            cmbIspl.Text = "";
            dpDate.SelectedDate = DateTime.Today;

            cmbYslyg.SelectedValuePath = "Код_Услуги";
            cmbYslyg.DisplayMemberPath = "Название";
            cmbYslyg.ItemsSource = ConnectHelper.entObj.Услуги.ToList();

            cmbIspl.SelectedValuePath = "Код_Исполнителя";
            cmbIspl.DisplayMemberPath = "ФИО";
            cmbIspl.ItemsSource = ConnectHelper.entObj.Исполнитель.ToList();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }

        private void btnAddDolzh_Click(object sender, RoutedEventArgs e)
        {
            if (cmbYslyg.Text == "" && tbOpis.Text == "" && dpDate.Text == "" && cmbIspl.Text == "")
            {
                MessageBox.Show("Поля нельзя оставлять пустыми!");
            }
            else if (dpDate.SelectedDate > DateTime.Today)
            {
                {
                    MessageBox.Show("Дата не может быть в будующем!");
                    dpDate.Text = "";
                }
            }
            else
            {
                try
                {
                    Заказ stdObj = new Заказ()
                    {

                        Услуги = cmbYslyg.SelectedItem as Услуги,
                        Исполнитель = cmbIspl.SelectedItem as Исполнитель,
                        Доп_Инфа = tbOpis.Text,
                        Код_Зазчика = zakazID,
                        Дата = (DateTime)dpDate.SelectedDate,
                        Код_Статуса = 1
                    };

                    ConnectHelper.entObj.Заказ.Add(stdObj);
                    ConnectHelper.entObj.SaveChanges();

                    MessageBox.Show("Заказ добавлен!",
                                    "Уведомление",
                                    MessageBoxButton.OK,
                                    MessageBoxImage.Information
                                    );

                }
                catch (Exception ex)
                {
                    MessageBox.Show(
                        "Критическая работа с приложением: " + ex.Message.ToString(),
                        "Уведомление",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning
                        );
                }
            }
        }
    }
}
