﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Интернет_Провайдер.DataFiles;
using Интернет_Провайдер.fAdmin.fAdd;

namespace Интернет_Провайдер.fAdmin
{
    /// <summary>
    /// Логика взаимодействия для PageMainAdd.xaml
    /// </summary>
    public partial class PageMainAdd : Page
    {
        public PageMainAdd()
        {
            InitializeComponent();
        }

        private void btnAddYsl_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageAddYsl());
        }

        private void btnAddIspoln_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageAddIspl());
        }

        private void btnAddCity_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageAddCity());
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }

        private void btnAddZakaz_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageAddZakaz());
        }

        private void btnAddСustomer_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageAddZakazchik());
        }
    }
}
