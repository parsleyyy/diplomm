﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Интернет_Провайдер.DataFiles;
using Интернет_Провайдер.fAdmin;
using Интернет_Провайдер.fZakazchick;

namespace Интернет_Провайдер
{
    /// <summary>
    /// Логика взаимодействия для PageLogin.xaml
    /// </summary>
    public partial class PageLogin : Page
    {
        private static int empID;
        public PageLogin()
        {
            InitializeComponent();
            tbLogin.Text = "";
            psPassword.Password = "";
        }

        public static int EmpID { get => empID; set => empID = value; }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            if (tbLogin.Text == "" && psPassword.Password == "")
            {
                MessageBox.Show("Поля нужно заполнить!", "Уведомление", MessageBoxButton.OKCancel);
            }
            else
            {
                try
                {
                    var userObj = ConnectHelper.entObj.Пользователь.FirstOrDefault(
                        x => x.Логин == tbLogin.Text && x.Пароль == psPassword.Password);

                    if (userObj == null)
                    {
                        MessageBox.Show("Такой пользователь отсутствует!",
                                    "Уведомление",
                                    MessageBoxButton.OK,
                                    MessageBoxImage.Information);
                    }
                    else
                    {
                        switch (userObj.Код_Роли)
                        {
                            case 1:
                                FrameApp.frmObj.Navigate(new PageMainAdmin());
                                break;

                            case 2:
                                EmpID = Convert.ToInt32(userObj.Код_Исполнителя);
                                FrameApp.frmObj.Navigate(new PageMainZak());
                                break;
                        }
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Критический сбор в работе приложения:" + ex.Message.ToString(),
                                    "Уведомление",
                                    MessageBoxButton.OK,
                                    MessageBoxImage.Warning);
                }
            }
        }

        private void BtnReg_Click(object sender, RoutedEventArgs e)
        {
            //FrameApp.frmObj.Navigate(new PageRegStep1());
        }
    }
}
