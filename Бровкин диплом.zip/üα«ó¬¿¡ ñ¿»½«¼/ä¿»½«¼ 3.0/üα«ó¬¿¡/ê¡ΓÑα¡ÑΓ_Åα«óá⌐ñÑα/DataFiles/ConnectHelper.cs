﻿namespace Интернет_Провайдер.DataFiles
{
    class ConnectHelper
    {
        public static Заявки_ИнтернетEntities entObj;
    }
}
