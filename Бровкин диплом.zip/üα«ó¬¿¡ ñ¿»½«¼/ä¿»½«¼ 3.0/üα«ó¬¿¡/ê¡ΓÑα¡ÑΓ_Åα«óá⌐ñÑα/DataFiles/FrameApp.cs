﻿using System.Windows.Controls;

namespace Интернет_Провайдер.DataFiles
{
    class FrameApp
    {
        public static Frame frmObj;
    }
}
